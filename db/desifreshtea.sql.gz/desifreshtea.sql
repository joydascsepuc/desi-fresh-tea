-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2021 at 09:46 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `desifreshtea`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(1, 'Why is Deshi Fresh Tea so different?', 'First we chose best tea gardens and producers. We make contract with them. Then we supervise entire tea leaf cultivation system. We provide technical and other support to our contract growers. Finally with our due supervision tea planters collect tea leaves. Obviously those are organic leaves. After that we run blending process. Through our high graded blending process we produce top class tea. As a result of our devoted attention our product becomes number one.', '2021-01-17 05:59:11', '2021-01-17 11:02:52'),
(3, 'Why is black tea so special??', 'Black tea is completely an oxidized tea. It gives more flavor than less oxidized tea. Moreover the flavor of black tea remains as it is for several years. For both the statics production and consumption black tea surpasses all other tea brand.', '2021-01-17 11:03:23', '2021-01-17 11:03:23');

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `image_name`, `created_at`, `updated_at`) VALUES
(15, 'gallery1_1610950173.jpg', '2021-01-18 00:09:33', '2021-01-18 00:09:33'),
(16, 'gallery2_1610950188.PNG', '2021-01-18 00:09:48', '2021-01-18 00:09:48'),
(17, 'gallery3_1610950199.jpg', '2021-01-18 00:09:59', '2021-01-18 00:09:59'),
(18, 'gallery4_1610950210.jpg', '2021-01-18 00:10:10', '2021-01-18 00:10:10'),
(19, 'gallery5_1610950331.jpg', '2021-01-18 00:12:11', '2021-01-18 00:12:11'),
(20, 'gallery6_1610950344.PNG', '2021-01-18 00:12:24', '2021-01-18 00:12:24'),
(21, 'gallery7_1610950354.jpg', '2021-01-18 00:12:35', '2021-01-18 00:12:35'),
(22, 'gallery8_1610950366.jpg', '2021-01-18 00:12:46', '2021-01-18 00:12:46'),
(23, 'gallery9_1610950527.jpg', '2021-01-18 00:15:27', '2021-01-18 00:15:27'),
(24, 'gallery10_1610950604.jpg', '2021-01-18 00:16:44', '2021-01-18 00:16:44'),
(25, 'gallery11_1610950626.jpg', '2021-01-18 00:17:06', '2021-01-18 00:17:06'),
(26, 'gallery12_1610950696.jpg', '2021-01-18 00:18:16', '2021-01-18 00:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `histories`
--

CREATE TABLE `histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `point` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `histories`
--

INSERT INTO `histories` (`id`, `point`, `created_at`, `updated_at`) VALUES
(1, 'If water is the first choice for drink surely tea is the second option.', '2021-01-17 07:47:27', '2021-01-18 02:06:44'),
(3, 'British people are the first inventor of tea plant at Sylhet in 1857 AD.', '2021-01-18 02:06:53', '2021-01-18 02:06:53'),
(4, 'It is Malni Canal is the place where tea is cultivated commercially at first.', '2021-01-18 02:07:03', '2021-01-18 02:07:03'),
(5, 'Tea industry is the traditional industry as well as one of the largest industrial sectors in this land.', '2021-01-18 02:07:14', '2021-01-18 02:07:14'),
(6, 'Deshi Fresh Tea started our tea leaf business journey in 2020 AD.', '2021-01-18 02:07:24', '2021-01-18 02:07:24'),
(7, 'We form business team having skilled tea business and cultivation experts.', '2021-01-18 02:07:36', '2021-01-18 02:07:36'),
(8, 'Satisfaction of customers is the prime choice of Deshi Fresh Tea.', '2021-01-18 02:07:47', '2021-01-18 02:07:47'),
(9, 'We also serious to protect interest of stockholders..', '2021-01-18 02:07:57', '2021-01-18 02:07:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_01_17_081520_create_website_contents_table', 2),
(5, '2021_01_17_093944_create_products_table', 3),
(6, '2021_01_17_114923_create_faqs_table', 4),
(7, '2021_01_17_121100_create_missions_table', 5),
(8, '2021_01_17_123003_create_visions_table', 6),
(9, '2021_01_17_133923_create_histories_table', 7),
(10, '2021_01_17_141857_create_galleries_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `missions`
--

CREATE TABLE `missions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `point` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `missions`
--

INSERT INTO `missions` (`id`, `point`, `created_at`, `updated_at`) VALUES
(1, 'We hope our Deshi Fresh Tea will be the world wide recognized food & beverage producer.', '2021-01-17 06:25:12', '2021-01-18 01:58:19'),
(3, 'Surely we will ensure top quality with proper nutrients.', '2021-01-18 01:58:30', '2021-01-18 01:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('joyd451@gmail.com', '$2y$10$LRbsI58VGAU3neT.4uZfAuPlFRIIbU4ERt/l1UYDzx8gxfzAMnqXy', '2021-01-17 09:57:30');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Green Tea', 'If you like to enjoy particular flavor and aroma from each brand that is to be different than other. Obviously you take green tea because each brand of green tea possesses different flavor and aroma than other brand.', '2021-01-17 03:58:41', '2021-01-18 01:23:37'),
(3, 'Tea bags- Black Tea', 'If you like to have a cup of tea with your small amount of tea leaves without sharing your tea leaves to other then this tea back is the right option. On the other hand you can get satisfaction at least partly to make your tea by your own hand.', '2021-01-18 01:20:05', '2021-01-18 01:24:30'),
(4, 'Black Tea', 'It is a black diamond for tea market. It is completely an oxidized tea. It gives more flavor than less oxidized tea. Moreover the flavor of black tea remains as it is for several years. For both the statics production and consumption black tea surpasses all other tea brand.', '2021-01-18 01:20:22', '2021-01-18 01:22:37'),
(5, 'Tea bags- Black Tea', 'It might be that just you the only one to have a cup of green tea but other like black tea. In such a situation this tea bag of green tea is the proper solution.', '2021-01-18 01:25:11', '2021-01-18 01:25:11'),
(6, 'Tea bags- Black Tea', 'Herbal is the latest trend and it is developing day by day. Obviously consumer gets some advantages of this herbal tea. Surely herbal tea will bring some relax to your some health hazards such as Diseases of the nostrils.', '2021-01-18 01:25:56', '2021-01-18 01:25:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Joy Das', 'joyd451@gmail.com', NULL, '$2y$10$IJXDbdlg0xfATsdnWUv0WenvNXgxmycWjfcyr7dTPcKUcYRBF1G7e', 'dSAEi9TOlGKYJ6kMqAn3yhkPdCm19Roc9W2nAo2tsP1b3x4b9uD2Gobebki1', '2021-01-16 23:08:21', '2021-01-16 23:08:21'),
(2, 'Joy Das', 'joyd41@gmail.com', NULL, '$2y$10$/9G.gO9qnxsR/6GnxZtWkeEveycjupBSN.wj8okxGjr55JJ7jUUKO', NULL, '2021-01-17 00:53:20', '2021-01-17 00:53:20');

-- --------------------------------------------------------

--
-- Table structure for table `visions`
--

CREATE TABLE `visions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `point` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `visions`
--

INSERT INTO `visions` (`id`, `point`, `created_at`, `updated_at`) VALUES
(1, 'Establish a sustainable tea industry.', '2021-01-17 06:39:01', '2021-01-18 01:58:50'),
(3, 'We keep in mind the great business idea that Customers are always right.', '2021-01-18 01:59:00', '2021-01-18 01:59:00'),
(4, 'So, it is our first & foremost duty to satisfy our customers.', '2021-01-18 01:59:10', '2021-01-18 01:59:10');

-- --------------------------------------------------------

--
-- Table structure for table `website_contents`
--

CREATE TABLE `website_contents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `about_company` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ceo_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `corporate_social_responsibility` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `website_contents`
--

INSERT INTO `website_contents` (`id`, `about_company`, `ceo_message`, `corporate_social_responsibility`, `created_at`, `updated_at`) VALUES
(1, 'Deshi Fresh Tea is dedicated to produce high quality fresh tea for you. We like to offer you feelings like a sweet dream when you have a sip on a cup of Deshi Fresh Tea.It is the blend making tea of the best tea leaves collecting those leaves with imposing very careful effort from the super class tea garden of Bangladesh. It would reach at your door in the top class packet so that the excellent fragrant and taste might remain protected. It is 100% ORGANIC the attracted licker and amusing fragrant will give you freshness for whole day long. We maintain our uncompromising commitment to our founding values in integrating to the heart of our business, respect for nature and future life on earth. We continuously strive to make its business sustainable since our journey.', 'Welcome to Deshi Fresh Tea. I feel proud to introduce our dedicated tea producing company before the honorable tea consumers. Please convey warm greetings of the business management team to all the customers and clients. Let me express regarding our structure. Soil and nature is the prime object to produce high quality tea. We choose the tea producers that have exact soil and natural support in producing high quality tea. You are our customer for organic tea. So, just after collecting raw tea leaves we start tea blending process. We provide latest equipments and machines to blend tea leaves. Our professional experts use latest scientific methods to blend tea. In fact upgrading our production process is a routine work. As a result we are confident and sure to offer you excellent tea in your cup. We also follow latest corporate business management procedure. Actually corporate management system is the key to show special importance to our honorable customers and consumers. We see our entire business motive with the attitudes of our consumers. Run business with consumers view point is the prime motto of our business. As tea is a food items and modern attitude is that no adulterated is allowed for food items. We strictly follow this view. Our final motto is to establish long lasting and permanent solid relation with our worthy customers. In fact we are heading towards future taking the best option of present period.', 'Business particularly corporate business is not only for earning, it is the modern idea and should be the motto of business community. We also follow this wise idea. At first we try to promote socio development of the land and people where we operate our business. We are fully conscious regarding environment pollution and to keep environment pollution free is one of the prime considerations of our business decision. Moreover we always follow the law of the country which is our business place and also show proper respect to the social custom of the people and society where we are to operate our business plan..', '2021-01-17 03:03:28', '2021-01-17 10:51:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `histories`
--
ALTER TABLE `histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `missions`
--
ALTER TABLE `missions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `visions`
--
ALTER TABLE `visions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `website_contents`
--
ALTER TABLE `website_contents`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `histories`
--
ALTER TABLE `histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `missions`
--
ALTER TABLE `missions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `visions`
--
ALTER TABLE `visions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `website_contents`
--
ALTER TABLE `website_contents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
